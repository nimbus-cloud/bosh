/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: 79677f478d5b0b9bf6ee23cd7f97bc7ca6b99929"
		" build by phil@fat-tyre, 2014-06-10 12:12:52";
}
